<script>
    // var data = {};
    // var posts = $$('._4-u2.mbm._4mrt._5jmm._5pat._5v3q._7cqq._4-u8') // 7 posts
    // posts.forEach(function (element, index) {
    //     var href = $$("#"+element.id+" a[rel=\"theater\"]")[0].href;
    //     data[index] = {};
    //
    //
    //     data[index]['id'] = /[^/]*$/.exec(href.substring(0, href.lastIndexOf('/')))[0];
    //
    //     data[index]['image'] =  $$("#"+element.id+" img")[1].src;
    //
    // });
    // console.log(
    //     data
    // )
</script>

