<?php
/*
   Plugin Name: Empty plugin
   Plugin URI: http://www.yourwebsitename.com/visit_plugin_website
   Description: An empty wordpress plugin
   Author: John Doe
   Author URI: http://www.yourwebsitename.com/plugin_by
   Version: 1.0.0
*/
?>
<?php
header('Access-Control-Allow-Origin: *');

require_once 'lib/functions.php';

if (isset($_GET['autopost'])) {
//    var_dump($_POST['autoP']);
//    exit();
    if (isset($_POST['autoP'])) {
        $ignores = explode(',', $_POST['autoP']['ignore']);
        foreach ($_POST['autoP'] as $k => $post) {
            if ($k != 'ignore' or $k == 'limit') {
                $k = $k + 1;

//                print_r($k);




                $contents = explode(' ', $post['content']);
//                var_dump($contents);
                    if (empty(array_intersect($ignores, $contents))) {
                        $P_NAME = to_slug($post['content']) . '-' . $post['id'];
                        if (count($wpdb->get_results("SELECT * FROM  wp_posts WHERE `post_name` = '$P_NAME'")) == 0) {
                            $wpdb->insert('wp_posts', array(
                                'post_author' => 1,
                                'post_date' => date("Y-m-d H:i:s", time()),
                                'post_date_gmt' => date("Y-m-d H:i:s", time()),
                                'post_content' => '<p>'
                                    . $post['content'] . '</p> ' .
                                    "<br>  <figure class=\"wp-block-image\"><img src='" . $post['image'] . "' alt='" . $post['content'] . "' title='" . $post['content'] . "'><figcaption>" . $post['content'] . "</figcaption> </figure>  ",
                                'post_title' => lv_get_title_post($post['content']) . " <!-- $k -->",
                                'post_name' => to_slug($post['content']) . '-' . $post['id'],
                            ));


                        }
                }



        }

    }

    echo '{"status":"good"}';
    exit();
} else {
    echo '{"status":"error! no post"}';
    exit;
}
}

?>